#!/bin/bash

set -e

echo "🚀 Iniciando setup do ambiente Mulder no Oracle Linux 8..."

# Etapa 1: Instalar dependências de build e Python 3.11
echo "🔧 Instalando dependências..."
dnf groupinstall -y "Development Tools"
dnf install -y gcc openssl-devel bzip2-devel libffi-devel wget make zlib-devel

echo "🐍 Baixando e compilando Python 3.11.9..."
cd /usr/src
wget https://www.python.org/ftp/python/3.11.9/Python-3.11.9.tgz
tar xvf Python-3.11.9.tgz
cd Python-3.11.9
./configure --enable-optimizations
make altinstall

# Etapa 2: Criar ambiente virtual
echo "📦 Criando virtualenv para o Mulder..."
/usr/local/bin/python3.11 -m venv /opt/mulder

# Etapa 3: Ativar a venv e instalar Ansible
echo "📦 Ativando virtualenv e instalando Ansible..."
source /opt/mulder/bin/activate
pip install --upgrade pip
pip install ansible

# Etapa 4: Instalar bibliotecas para integração com ESXi
echo "🔌 Instalando bibliotecas para integração com VMware ESXi..."
pip install pyvmomi requests

# Etapa 5: Instalar a collection community.vmware
echo "📦 Instalando a collection community.vmware..."
ansible-galaxy collection install community.vmware

# Etapa 6: Criar estrutura de diretórios do Mulder
echo "📁 Criando estrutura de diretórios do Mulder..."
mkdir -p /opt/mulder/playbooks /opt/mulder/secrets
cd /tmp/mulder ; cp ansible.cfg snapshot.yml snap.sh /opt/mulder/playbooks/
cp secrets.yml /opt/mulder/secrets/
cp /tmp/mulder/configure-snapshot.sh /opt/mulder/
echo "alias MULDER='source /opt/mulder/bin/activate'" >> /root/.bashrc
alias MULDER='source /opt/mulder/bin/activate'

echo "✅ Ambiente pronto! Playbooks estão em: /opt/mulder/playbooks"
echo "   Para ativar o ambiente: exetute o comando MULDER"

