#!/bin/bash

echo "CONFIGURANDO RECURSOS PARA SNAPSHOT"
echo ""
# Caminhos dos arquivos
SNAP_SCRIPT="/opt/mulder/playbooks/snap.sh"
SECRETS_FILE="/opt/mulder/secrets/secrets.yml"

# Solicita os dados ao usuário
read -p "Nome da VM: " VMNAME
read -p "Nome base do snapshot: " SNAPNAME
read -p "IP ou hostname do vCenter: " VCENTER
read -p "Usuário do vCenter: " VCUSER
read -s -p "Senha do vCenter: " VCPASS
echo ""

# Faz as substituições de entradas
sed -i "s|VMNAME|$VMNAME|g" "$SNAP_SCRIPT"
sed -i "s|SNAPNAME|$SNAPNAME|g" "$SNAP_SCRIPT"
sed -i "s|VECENTERHOST|$VCENTER|g" "$SECRETS_FILE"
sed -i "s|USER|$VCUSER|g" "$SECRETS_FILE"
sed -i "s|PASS|$VCPASS|g" "$SECRETS_FILE"
echo ""
echo "CONFIGURAÇÕES REALIZADAS COM SUCESSO!"
echo "Execute o snapshot com o comando /opt/mulder/playbooks/snap.sh"
