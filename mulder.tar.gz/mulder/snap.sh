#!/bin/bash

VM_NAME="CLLBROKER-1"
SNAP_NAME="Snap_$(date +%Y%m%d_%H%M%S)"
PLAYBOOK="snapshot.yml"

ansible-playbook -i localhost, "$PLAYBOOK" \
  -e vm_name="$VM_NAME" \
  -e snap_name="$SNAP_NAME"
