#!/bin/bash

clear
echo "CONFIGURANDO RECURSOS PARA SNAPSHOT"
echo ""
# Caminhos dos arquivos
SECRETS_FILE="/opt/mulder/secrets/secrets.yml"

# Solicita os dados ao usuário
read -p "IP ou hostname do vCenter: " VCENTER
read -p "Usuário do vCenter: " VCUSER
read -s -p "Senha do vCenter: " VCPASS
echo ""

# Faz as substituições de entradas
sed -i "s|VECENTERHOST|$VCENTER|g" "$SECRETS_FILE"
sed -i "s|USER|$VCUSER|g" "$SECRETS_FILE"
sed -i "s|PASS|$VCPASS|g" "$SECRETS_FILE"
echo ""
echo "CONFIGURAÇÕES REALIZADAS COM SUCESSO!"
