#!/bin/bash

VM_NAME="VMNAME"
SNAP_NAME="SNAPNAME_$(date +%Y%m%d_%H%M%S)"
PLAYBOOK="snapshot.yml"

ansible-playbook -i localhost, "$PLAYBOOK" \
  -e vm_name="$VM_NAME" \
  -e snap_name="$SNAP_NAME"
